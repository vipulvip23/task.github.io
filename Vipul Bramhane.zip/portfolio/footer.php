  <!-- start section footer -->
  <div id="footer" class="text-center">
    <div class="container">
      <div class="socials-media text-center">

        <ul class="list-unstyled">
          <li><a href="https://www.facebook.com/vipul.bramhane.1"><i class="ion-social-facebook"></i></a></li>
          <li><a href="https://twitter.com/vipul_vip23?s=20"><i class="ion-social-twitter"></i></a></li>
          <li><a href="https://instagram.com/vipul__vip?utm_medium=copy_link"><i class="ion-social-instagram"></i></a></li>
          <li><a href="#"><i class="ion-social-googleplus"></i></a></li>
          <li><a href="#"><i class="ion-social-tumblr"></i></a></li>
          <li><a href="#"><i class="ion-social-dribbble"></i></a></li>
        </ul>

      </div>

      <p>&copy; Copyrights 2022.<b style="color: chocolate;">All rights reserved.</b></p>

      <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Folio
        -->
        Designed by <a href="https://bootstrapmade.com/"><b style="color:chocolate;">Vipul Bramhane</b></a>
      </div>

    </div>
  </div>
  <!-- End section footer -->
